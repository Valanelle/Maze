import { _decorator, CircleCollider2D, Collider2D, Component, Contact2DType, EventKeyboard, Input, input, IPhysics2DContact, KeyCode, Vec3 } from 'cc';
import { GameProperties } from '../Properties/GameProperties';
const { ccclass, property } = _decorator;

@ccclass('PlayerController')
export class PlayerController extends Component {

    startPostion: Vec3 = new Vec3(0, 0, 0);

    start() {
        input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        let collider = this.getComponent(CircleCollider2D);
        if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
        }
        this.node.on('playerStop', this.playerStop, this);
    }

    update(deltaTime: number) {
        if (this._startJump) {
            this.node.setPosition(this._curPos);
            this._startJump = false;
        }
    }

    private _startJump: boolean = false;
    private _curPos: Vec3 = new Vec3();
    private _stepNum: number = 32;
    private _nowCurPos: Vec3 = new Vec3();

    onKeyDown(event: EventKeyboard) {
        if (this._startJump) {
            return;
        }
        this._startJump = true;
        this.node.getPosition(this._curPos);
        this.node.getPosition(this._nowCurPos);
        if (KeyCode.KEY_W === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(0, this._stepNum, 0));
        } else if (KeyCode.KEY_S === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(0, -this._stepNum, 0));
        } else if (KeyCode.KEY_A === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(-this._stepNum, 0, 0));
        } else if (KeyCode.KEY_D === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(this._stepNum, 0, 0));
        } else if (KeyCode.SPACE === event.keyCode) {
            this.node.parent.emit('changeGameStatus');
            return;
        }
        this.updateMove();
    }

    updateMove() {
        GameProperties.moveNum++;
        this.node.parent.emit('updateTopMove');
    }

    onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        // 只在两个碰撞体开始接触时被调用一次
        if (otherCollider.node.name === "DestinationWall") {
            //抵达出口，游戏结束
            GameProperties.mapLevel++
            this.node.parent.emit('changeMap');
        }
        this.node.position = this.startPostion;

    }

    playerStop() {
        console.log("game over");
        input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
    }
}

