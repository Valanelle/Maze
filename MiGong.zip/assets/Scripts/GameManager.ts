import { _decorator, Camera, Component, director, instantiate, Node, Prefab, resources, sys, Vec3 } from 'cc';
import { GameProperties } from './Properties/GameProperties';
const { ccclass, property } = _decorator;

interface RecordData {
    level: number;
    moveNum: number;
    dateTime: Date;
}

@ccclass('GameManager')
export class GameManager extends Component {
    wallManager: Prefab = null;

    player: Prefab = null;

    camera: Camera = null;

    playerNode: Node = null;
    @property(Node)
    uiRestart: Node = null;
    @property(Node)
    uiStart: Node = null;

    start() {
        /**
         * 动态加载地图管理器
         */
        resources.load('Prefabs/WallManager', Prefab, (err, prefab) => {
            if (err) {
                console.error(err);
                return;
            }
            this.wallManager = prefab;
            this.changeMap();
        });
        this.node.on('changeMap', this.changeMap, this);
        this.node.on('changeGameStatus', this.changeGameStatus, this);
        this.node.on('gameOver', this.gameOver, this);
        this.camera = this.node.getChildByName('Camera').getComponent(Camera);
        /**
         * 动态加载玩家
         */
        resources.load('Prefabs/Player', Prefab, (err, prefab) => {
            if (err) {
                console.error(err);
                return;
            }
            this.player = prefab;
            this.playerNode = instantiate(this.player);
            director.getScene().getChildByName('Canvas').addChild(this.playerNode);
        });
        director.pause();
    }
    /**
     * 生成新的地图
     */
    changeMap() {
        this.node.getChildByName('WallManager')?.destroy();
        const wallManagerNode = instantiate(this.wallManager);
        director.getScene().getChildByName('Canvas').insertChild(wallManagerNode, 1);
    }
    /**
     * 游戏结束
     */
    gameOver() {
        this.uiRestart.active = true;
        director.pause();
        const records = sys.localStorage.getItem('userData');
        console.log(records);
        const record: RecordData = {
            level: GameProperties.mapLevel,
            moveNum: GameProperties.moveNum,
            dateTime: new Date()
        }
        if (records == null) {
            sys.localStorage.setItem('userData', JSON.stringify(record));
        } else {
            const lastRecord = JSON.parse(records) as RecordData;
            if (lastRecord.level < GameProperties.mapLevel) {
                sys.localStorage.setItem('userData', JSON.stringify(record));
            }
        }
    }

    /**
     * 限时模式开始游戏
     */
    xsStartGame() {
        GameProperties.gameType = 1;
        this.startGame();
    }

    /**
     * 无尽模式开始游戏
     */
    wjStartGame() {
        GameProperties.gameType = 2;
        this.startGame();
    }

    startGame() {
        this.uiRestart.active = false;
        this.uiStart.active = false;
        GameProperties.mapLevel = 1;
        GameProperties.moveNum = 0;
        if (GameProperties.gameType == 1) {
            GameProperties.timeNum = 30;
        }
        this.playerNode.position = new Vec3(0, 0, 0);
        this.changeMap();
        director.resume();
    }

    /**
     * 切换游戏状态
     */
    changeGameStatus() {
        if (director.isPaused()) {
            director.resume();
        } else {
            director.pause();
        }
    }
}

