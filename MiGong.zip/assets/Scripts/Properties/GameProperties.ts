import { _decorator } from 'cc';

export class GameProperties {

    static moveNum: number = 0;// 移动次数

    static mapWidth: number = 21;// 地图宽度

    static mapHeight: number = 21;// 地图高度

    static mapLevel: number = 1;// 地图等级

    static timeNum: number = 0; // 时间

    static gameType: number = 2; // 游戏类型,1为30秒倒计时,2为无尽模式

}