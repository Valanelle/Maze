import { _decorator, LabelComponent, Component } from "cc";
import { GameProperties } from "../Properties/GameProperties";
const { ccclass, property } = _decorator;

/**
 * UI控制器
 */
@ccclass('UIController')
export class UIController extends Component {

    @property(LabelComponent)
    moveNumLabel: LabelComponent = null;
    @property(LabelComponent)
    levelNumLabel: LabelComponent = null;
    @property(LabelComponent)
    dateLabel: LabelComponent = null;
    start() {
        this.node.on('updateUIMoveNum', this.updateMoveNum, this);
        this.node.on('updateUILevelNum', this.updateLevelNum, this)
    }

    protected update(dt: number): void {
        this.updateMoveNum();
        this.updateLevelNum();
        if (GameProperties.gameType === 1) {
            GameProperties.timeNum -= dt;
            this.dateLabel.string = GameProperties.timeNum.toFixed(1);
            if (GameProperties.timeNum <= 0) {
                this.node.parent.emit('gameOver');
            }
        } else {
            GameProperties.timeNum += dt;
            this.dateLabel.string = GameProperties.timeNum.toFixed(1);
        }
    }

    updateMoveNum() {
        this.moveNumLabel.string = GameProperties.moveNum.toString();
    }

    updateLevelNum() {
        this.levelNumLabel.string = GameProperties.mapLevel.toString();
    }
}