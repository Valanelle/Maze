System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, instantiate, Prefab, resources, GameProperties, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, MapController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameProperties(extras) {
    _reporterNs.report("GameProperties", "../Properties/GameProperties", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      instantiate = _cc.instantiate;
      Prefab = _cc.Prefab;
      resources = _cc.resources;
    }, function (_unresolved_2) {
      GameProperties = _unresolved_2.GameProperties;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "971222wj4ZIRbURjq8XnTnH", "MapController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'instantiate', 'Node', 'Prefab', 'resources']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("MapController", MapController = (_dec = ccclass('MapController'), _dec2 = property({
        type: Prefab
      }), _dec3 = property({
        type: Prefab
      }), _dec(_class = (_class2 = class MapController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "boxPrefab", _descriptor, this);

          _initializerDefineProperty(this, "DestinationPrefab", _descriptor2, this);

          this.width = 21;
          //整体宽度
          this.height = 21;
          //整体高度
          this.maze = void 0;
          this.zx_x = (this.width - 1) / 2;
          //中心坐标x
          this.zx_y = (this.height - 1) / 2;
          //中心坐标y
          this._step = 32;
          //步长
          this.zd_x = this.width - 2;
          //终点坐标x
          this.zd_y = this.height - 1;
        }

        //终点坐标y
        start() {
          if (this.boxPrefab === null) {
            resources.load('Prefabs/Wall', Prefab, (err, prefab) => {
              if (err) {
                console.error(err);
                return;
              }

              this.boxPrefab = prefab;
            });
          }

          if (this.DestinationPrefab === null) {
            resources.load('Prefabs/DestinationWall', Prefab, (err, prefab) => {
              if (err) {
                console.error(err);
                return;
              }

              this.DestinationPrefab = prefab;
            });
          }

          this.width = (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).mapWidth;
          this.height = (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).mapHeight; // PhysicsSystem2D.instance.enable = true;

          this.width = this.width % 2 === 0 ? this.width + 1 : this.width; // 确保宽度为奇数

          this.height = this.height % 2 === 0 ? this.height + 1 : this.height;
          this.maze = this.initializeMaze(); // this.maze[this.zx_x][this.zx_y] = 0;

          this.generateMaze(1, 1); // 从 (1, 1) 开始生成迷宫

          this.generateOutWall(); // 在外墙上随机开一个口子

          this.printMaze(); // 打印迷宫
        }

        update(deltaTime) {}

        initializeMaze() {
          const maze = [];

          for (let i = 0; i < this.height; i++) {
            maze[i] = [];

            for (let j = 0; j < this.width; j++) {
              // 将所有单元初始化为墙壁
              maze[i][j] = 1;
            }
          }

          maze[this.zx_x][this.zx_y] = 0; //以中心点边上设置为0，避免被困住中心点

          maze[this.zx_x - 1][this.zx_y] = 0;
          return maze;
        } //在外墙上随机开一个口子


        generateOutWall() {
          const fxs = [1, 2, 3, 4];
          const fx = fxs[Math.floor(Math.random() * fxs.length)];
          let directions = [];
          let x = 1;
          let y = 1;

          switch (fx) {
            case 1:
              directions = [{
                dx: -1,
                dy: 0
              }, // 左
              {
                dx: 0,
                dy: -1
              } // 上
              ];
              break;

            case 2:
              directions = [{
                dx: 1,
                dy: 0
              }, // 右
              {
                dx: 0,
                dy: -1
              } // 上
              ];
              x = this.width - 2;
              break;

            case 3:
              directions = [{
                dx: -1,
                dy: 0
              }, // 左
              {
                dx: 0,
                dy: 1
              } // 下
              ];
              y = this.height - 2;
              break;

            case 4:
              directions = [{
                dx: 1,
                dy: 0
              }, // 右
              {
                dx: 0,
                dy: 1
              } // 下
              ];
              x = this.width - 2;
              y = this.height - 2;
              break;

            default:
              break;
          }

          const dir = directions[Math.floor(Math.random() * directions.length)];
          x += dir.dx;
          y += dir.dy;
          console.log(`出口数组值：(${y}, ${x})`);

          if (this.maze[y][x] === 1) {
            // this.maze[this.zd_y][this.zd_x] = 0; // 打通新单元
            this.zd_x = this.zx_y - y;
            this.zd_y = x - this.zx_x;
            console.log(`出口生成完成，坐标：(${this.zd_x}, ${this.zd_y})`);
          }
        }

        generateMaze(x, y) {
          const directions = [{
            dx: 2,
            dy: 0
          }, // 右
          {
            dx: -2,
            dy: 0
          }, // 左
          {
            dx: 0,
            dy: 2
          }, // 下
          {
            dx: 0,
            dy: -2
          } // 上
          ]; // 打乱方向顺序

          this.shuffleArray(directions);

          for (const dir of directions) {
            const newX = x + dir.dx;
            const newY = y + dir.dy; // 检查新坐标是否在边界内且未被访问

            if (this.isInBounds(newX, newY) && this.maze[newY][newX] === 1) {
              this.maze[y + dir.dy / 2][x + dir.dx / 2] = 0; // 打通墙壁

              this.maze[newY][newX] = 0; // 打通新单元

              this.generateMaze(newX, newY); // 递归生成
            }
          }
        }

        isInBounds(x, y) {
          return x > 0 && x < this.width && y > 0 && y < this.height;
        }

        shuffleArray(array) {
          for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
          }
        }

        printMaze() {
          let y = this.zx_y;

          for (const row of this.maze) {
            //以zx_x和zx_y坐标作为坐标原点，得出组数中每个格子的坐标
            let x = 0 - this.zx_x;
            let block = null;

            for (const cell of row) {
              if (cell === 1) {
                // console.log(`(${x}, ${y})`);
                if (x === this.zd_x && y === this.zd_y) {
                  // console.log(`(${this.zd_x}, ${this.zd_y})`);
                  block = instantiate(this.DestinationPrefab);
                } else {
                  block = instantiate(this.boxPrefab);
                }

                this.node.addChild(block);
                block.setPosition(x * this._step, y * this._step, 0);
              }

              x += 1;
            }

            y -= 1;
          }
        }

        isEnd(x, y) {
          return x / this._step === this.zd_y && y / this._step === this.zd_x;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "boxPrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "DestinationPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=cfda361f4b9b81357a1b9d06b5f5de2aa4760ab7.js.map