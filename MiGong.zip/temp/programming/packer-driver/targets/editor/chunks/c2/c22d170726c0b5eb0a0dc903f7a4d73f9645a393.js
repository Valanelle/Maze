System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, LabelComponent, Component, GameProperties, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, UIController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameProperties(extras) {
    _reporterNs.report("GameProperties", "../Properties/GameProperties", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      LabelComponent = _cc.LabelComponent;
      Component = _cc.Component;
    }, function (_unresolved_2) {
      GameProperties = _unresolved_2.GameProperties;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "da5d4S3SZVMhp5ti72shNXv", "UIController", undefined);

      __checkObsolete__(['_decorator', 'LabelComponent', 'Component']);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * UI控制器
       */

      _export("UIController", UIController = (_dec = ccclass('UIController'), _dec2 = property(LabelComponent), _dec3 = property(LabelComponent), _dec4 = property(LabelComponent), _dec(_class = (_class2 = class UIController extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "moveNumLabel", _descriptor, this);

          _initializerDefineProperty(this, "levelNumLabel", _descriptor2, this);

          _initializerDefineProperty(this, "dateLabel", _descriptor3, this);
        }

        start() {
          this.node.on('updateUIMoveNum', this.updateMoveNum, this);
          this.node.on('updateUILevelNum', this.updateLevelNum, this);
        }

        update(dt) {
          this.updateMoveNum();
          this.updateLevelNum();

          if ((_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).gameType === 1) {
            (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).timeNum -= dt;
            this.dateLabel.string = (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).timeNum.toFixed(1);

            if ((_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).timeNum <= 0) {
              this.node.parent.emit('gameOver');
            }
          } else {
            (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).timeNum += dt;
            this.dateLabel.string = (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).timeNum.toFixed(1);
          }
        }

        updateMoveNum() {
          this.moveNumLabel.string = (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).moveNum.toString();
        }

        updateLevelNum() {
          this.levelNumLabel.string = (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).mapLevel.toString();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "moveNumLabel", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "levelNumLabel", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "dateLabel", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=c22d170726c0b5eb0a0dc903f7a4d73f9645a393.js.map