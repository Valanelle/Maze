System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, GameProperties, _crd;

  _export("GameProperties", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "47e4dQ9OlJK35BW2KDBw1ua", "GameProperties", undefined);

      __checkObsolete__(['_decorator']);

      _export("GameProperties", GameProperties = class GameProperties {});

      GameProperties.moveNum = 0;
      // 移动次数
      GameProperties.mapWidth = 21;
      // 地图宽度
      GameProperties.mapHeight = 21;
      // 地图高度
      GameProperties.mapLevel = 1;
      // 地图等级
      GameProperties.timeNum = 0;
      // 时间
      GameProperties.gameType = 2;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1919beaca2020419b42fe2bc83636626165e3ab6.js.map