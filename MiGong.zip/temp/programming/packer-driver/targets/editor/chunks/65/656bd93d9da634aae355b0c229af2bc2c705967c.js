System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Camera, Component, director, instantiate, Node, Prefab, resources, sys, Vec3, GameProperties, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, GameManager;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGameProperties(extras) {
    _reporterNs.report("GameProperties", "./Properties/GameProperties", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Camera = _cc.Camera;
      Component = _cc.Component;
      director = _cc.director;
      instantiate = _cc.instantiate;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      resources = _cc.resources;
      sys = _cc.sys;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      GameProperties = _unresolved_2.GameProperties;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a675bttnlxKw4vqk8OXWgZf", "GameManager", undefined);

      __checkObsolete__(['_decorator', 'Camera', 'Component', 'director', 'instantiate', 'Node', 'Prefab', 'resources', 'sys', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("GameManager", GameManager = (_dec = ccclass('GameManager'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = class GameManager extends Component {
        constructor(...args) {
          super(...args);
          this.wallManager = null;
          this.player = null;
          this.camera = null;
          this.playerNode = null;

          _initializerDefineProperty(this, "uiRestart", _descriptor, this);

          _initializerDefineProperty(this, "uiStart", _descriptor2, this);
        }

        start() {
          /**
           * 动态加载地图管理器
           */
          resources.load('Prefabs/WallManager', Prefab, (err, prefab) => {
            if (err) {
              console.error(err);
              return;
            }

            this.wallManager = prefab;
            this.changeMap();
          });
          this.node.on('changeMap', this.changeMap, this);
          this.node.on('changeGameStatus', this.changeGameStatus, this);
          this.node.on('gameOver', this.gameOver, this);
          this.camera = this.node.getChildByName('Camera').getComponent(Camera);
          /**
           * 动态加载玩家
           */

          resources.load('Prefabs/Player', Prefab, (err, prefab) => {
            if (err) {
              console.error(err);
              return;
            }

            this.player = prefab;
            this.playerNode = instantiate(this.player);
            director.getScene().getChildByName('Canvas').addChild(this.playerNode);
          });
          director.pause();
        }
        /**
         * 生成新的地图
         */


        changeMap() {
          var _this$node$getChildBy;

          (_this$node$getChildBy = this.node.getChildByName('WallManager')) == null || _this$node$getChildBy.destroy();
          const wallManagerNode = instantiate(this.wallManager);
          director.getScene().getChildByName('Canvas').insertChild(wallManagerNode, 1);
        }
        /**
         * 游戏结束
         */


        gameOver() {
          this.uiRestart.active = true;
          director.pause();
          const records = sys.localStorage.getItem('userData');
          console.log(records);
          const record = {
            level: (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).mapLevel,
            moveNum: (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).moveNum,
            dateTime: new Date()
          };

          if (records == null) {
            sys.localStorage.setItem('userData', JSON.stringify(record));
          } else {
            const lastRecord = JSON.parse(records);

            if (lastRecord.level < (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).mapLevel) {
              sys.localStorage.setItem('userData', JSON.stringify(record));
            }
          }
        }
        /**
         * 限时模式开始游戏
         */


        xsStartGame() {
          (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).gameType = 1;
          this.startGame();
        }
        /**
         * 无尽模式开始游戏
         */


        wjStartGame() {
          (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).gameType = 2;
          this.startGame();
        }

        startGame() {
          this.uiRestart.active = false;
          this.uiStart.active = false;
          (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).mapLevel = 1;
          (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).moveNum = 0;

          if ((_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).gameType == 1) {
            (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).timeNum = 30;
          }

          this.playerNode.position = new Vec3(0, 0, 0);
          this.changeMap();
          director.resume();
        }
        /**
         * 切换游戏状态
         */


        changeGameStatus() {
          if (director.isPaused()) {
            director.resume();
          } else {
            director.pause();
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "uiRestart", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "uiStart", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=656bd93d9da634aae355b0c229af2bc2c705967c.js.map