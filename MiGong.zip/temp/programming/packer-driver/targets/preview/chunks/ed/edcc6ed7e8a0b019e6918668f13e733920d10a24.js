System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, CircleCollider2D, Component, Contact2DType, Input, input, KeyCode, Vec3, GameProperties, _dec, _class, _crd, ccclass, property, PlayerController;

  function _reportPossibleCrUseOfGameProperties(extras) {
    _reporterNs.report("GameProperties", "../Properties/GameProperties", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      CircleCollider2D = _cc.CircleCollider2D;
      Component = _cc.Component;
      Contact2DType = _cc.Contact2DType;
      Input = _cc.Input;
      input = _cc.input;
      KeyCode = _cc.KeyCode;
      Vec3 = _cc.Vec3;
    }, function (_unresolved_2) {
      GameProperties = _unresolved_2.GameProperties;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a499alqYdxEHLagbwqmqUj7", "PlayerController", undefined);

      __checkObsolete__(['_decorator', 'CircleCollider2D', 'Collider2D', 'Component', 'Contact2DType', 'EventKeyboard', 'Input', 'input', 'IPhysics2DContact', 'KeyCode', 'Vec3']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("PlayerController", PlayerController = (_dec = ccclass('PlayerController'), _dec(_class = class PlayerController extends Component {
        constructor() {
          super(...arguments);
          this.startPostion = new Vec3(0, 0, 0);
          this._startJump = false;
          this._curPos = new Vec3();
          this._stepNum = 32;
          this._nowCurPos = new Vec3();
        }

        start() {
          input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          var collider = this.getComponent(CircleCollider2D);

          if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
          }

          this.node.on('playerStop', this.playerStop, this);
        }

        update(deltaTime) {
          if (this._startJump) {
            this.node.setPosition(this._curPos);
            this._startJump = false;
          }
        }

        onKeyDown(event) {
          if (this._startJump) {
            return;
          }

          this._startJump = true;
          this.node.getPosition(this._curPos);
          this.node.getPosition(this._nowCurPos);

          if (KeyCode.KEY_W === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(0, this._stepNum, 0));
          } else if (KeyCode.KEY_S === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(0, -this._stepNum, 0));
          } else if (KeyCode.KEY_A === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(-this._stepNum, 0, 0));
          } else if (KeyCode.KEY_D === event.keyCode) {
            Vec3.add(this._curPos, this._curPos, new Vec3(this._stepNum, 0, 0));
          } else if (KeyCode.SPACE === event.keyCode) {
            this.node.parent.emit('changeGameStatus');
            return;
          }

          this.updateMove();
        }

        updateMove() {
          (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
            error: Error()
          }), GameProperties) : GameProperties).moveNum++;
          this.node.parent.emit('updateTopMove');
        }

        onBeginContact(selfCollider, otherCollider, contact) {
          // 只在两个碰撞体开始接触时被调用一次
          if (otherCollider.node.name === "DestinationWall") {
            //抵达出口，游戏结束
            (_crd && GameProperties === void 0 ? (_reportPossibleCrUseOfGameProperties({
              error: Error()
            }), GameProperties) : GameProperties).mapLevel++;
            this.node.parent.emit('changeMap');
          }

          this.node.position = this.startPostion;
        }

        playerStop() {
          console.log("game over");
          input.off(Input.EventType.KEY_DOWN, this.onKeyDown, this);
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=edcc6ed7e8a0b019e6918668f13e733920d10a24.js.map